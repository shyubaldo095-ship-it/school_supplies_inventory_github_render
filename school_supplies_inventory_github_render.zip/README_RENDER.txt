SCHOOL SUPPLIES INVENTORY - GITHUB + RENDER

FILES
- school_supplies_inventory.py : the Python web application
- requirements.txt             : dependencies (standard library only)
- render.yaml                  : Render deployment configuration

DEPLOYMENT
1. Create a GitHub repository.
2. Upload all three files to the repository's root folder.
3. In Render, choose New + -> Blueprint and connect that GitHub repository.
4. Render reads render.yaml. The configuration uses a persistent disk mounted at
   /var/data so inventory.db can survive restarts and redeploys. The configured
   Starter service and persistent disk may incur charges; check Render's current
   pricing before confirming deployment.
5. In Render, set ADMIN_PASSWORD and STAFF_PASSWORD to strong, different passwords.
6. Deploy. Open the public URL Render gives you.

IMPORTANT
- GitHub Pages cannot run this Python backend. Use Render as the web host.
- The app binds to 0.0.0.0 and uses Render's PORT environment variable.
- The SQLite database is stored under RENDER_DISK_PATH. Keep the persistent disk
  mounted at /var/data; without a persistent disk, data may be lost on redeploy.
- On a brand-new database, the default demo passwords are admin/123 and staff/123
  unless you set ADMIN_PASSWORD and STAFF_PASSWORD before the first deployment.
  Set both environment variables before publishing the site.
- Existing user records are not overwritten when the database already contains
  those usernames. Changing environment variables does not change existing
  account passwords. Change those passwords through a suitable account-management
  feature or use a fresh database for a new deployment.
- This is a classroom project implementation, not a production-hardened system.
