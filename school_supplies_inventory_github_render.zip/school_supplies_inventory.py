"""School Supplies Inventory - Data Structures Final Project"""

import hashlib

import hmac

import json

import math

import os

import secrets

import sqlite3

import subprocess

import sys

import threading

import time

import webbrowser

from collections import deque

from http.cookies import SimpleCookie

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from urllib.parse import urlparse

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8000"))
# On Render, set a persistent disk mount path such as /var/data.
DATA_DIR = os.environ.get("RENDER_DISK_PATH", os.path.dirname(os.path.abspath(__file__)))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "inventory.db")

SESSION_TTL_SECONDS = 8 * 60 * 60

PASSWORD_ITERATIONS = 300_000

MAX_REQUEST_BYTES = 100_000

# These accounts are added only if they do not already exist.

DEMO_USERS = {

    "admin": ("123", "admin"),

    "staff": ("123", "staff"),

}

SESSIONS = {}

SESSIONS_LOCK = threading.Lock()

DATA_LOCK = threading.RLock()

INVENTORY_LIST = []

RESTOCK_QUEUE = deque()

def db():

    conn = sqlite3.connect(DB_PATH, timeout=15)

    conn.row_factory = sqlite3.Row

    conn.execute("PRAGMA foreign_keys = ON")

    return conn

def hash_password(password, salt=None):

    salt = salt or secrets.token_bytes(16)

    digest = hashlib.pbkdf2_hmac(

        "sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS

    )

    return salt.hex() + "$" + digest.hex()

def verify_password(password, stored):

    try:

        salt_hex, expected_hex = stored.split("$", 1)

        actual = hashlib.pbkdf2_hmac(

            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), PASSWORD_ITERATIONS

        ).hex()

        return hmac.compare_digest(actual, expected_hex)

    except (ValueError, TypeError, AttributeError):

        return False

def init_db():

    with db() as conn:

        conn.execute("""

            CREATE TABLE IF NOT EXISTS items (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                name TEXT NOT NULL,

                category TEXT NOT NULL DEFAULT 'Other',

                quantity INTEGER NOT NULL DEFAULT 0,

                min_stock INTEGER NOT NULL DEFAULT 5,

                price REAL NOT NULL DEFAULT 0

            )

        """)

        conn.execute("""

            CREATE TABLE IF NOT EXISTS users (

                username TEXT PRIMARY KEY,

                password_hash TEXT NOT NULL,

                role TEXT NOT NULL CHECK(role IN ('admin','staff'))

            )

        """)

        conn.execute("""

            CREATE TABLE IF NOT EXISTS restock_requests (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                item_id INTEGER NOT NULL,

                item_name TEXT NOT NULL,

                requested_qty INTEGER NOT NULL CHECK(requested_qty > 0),

                requested_by TEXT NOT NULL,

                note TEXT NOT NULL DEFAULT '',

                status TEXT NOT NULL DEFAULT 'Pending'

                    CHECK(status IN ('Pending','Approved','Rejected')),

                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

                processed_by TEXT,

                processed_at TEXT,

                FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE

            )

        """)

        existing_columns = {

            row["name"] for row in conn.execute("PRAGMA table_info(restock_requests)").fetchall()

        }

        added_requested_qty = "requested_qty" not in existing_columns

        migrations = {

            "item_id": "INTEGER NOT NULL DEFAULT 0",

            "item_name": "TEXT NOT NULL DEFAULT ''",

            "requested_qty": "INTEGER NOT NULL DEFAULT 1",

            "requested_by": "TEXT NOT NULL DEFAULT ''",

            "note": "TEXT NOT NULL DEFAULT ''",

            "status": "TEXT NOT NULL DEFAULT 'Pending'",

            "created_at": "TEXT NOT NULL DEFAULT ''",

            "processed_by": "TEXT",

            "processed_at": "TEXT",

        }

        for column, definition in migrations.items():

            if column not in existing_columns:

                conn.execute(f"ALTER TABLE restock_requests ADD COLUMN {column} {definition}")

        if added_requested_qty:

            old_amount_column = next(

                (name for name in ("requested_quantity", "request_qty", "quantity", "qty")

                 if name in existing_columns),

                None,

            )

            if old_amount_column:

                conn.execute(

                    f"UPDATE restock_requests SET requested_qty = "

                    f"CASE WHEN CAST({old_amount_column} AS INTEGER) > 0 "

                    f"THEN CAST({old_amount_column} AS INTEGER) ELSE 1 END"

                )

        conn.execute("""

            UPDATE restock_requests

            SET item_name = COALESCE(

                (SELECT name FROM items WHERE items.id = restock_requests.item_id),

                'Unknown item'

            )

            WHERE item_name IS NULL OR item_name = ''

        """)

        conn.execute(

            "UPDATE restock_requests SET created_at = CURRENT_TIMESTAMP "

            "WHERE created_at IS NULL OR created_at = ''"

        )

        conn.execute(

            "UPDATE restock_requests SET status = 'Pending' "

            "WHERE status IS NULL OR status NOT IN ('Pending','Approved','Rejected')"

        )

        for username, (password, role) in DEMO_USERS.items():

            found = conn.execute(

                "SELECT username FROM users WHERE username = ?", (username,)

            ).fetchone()

            if found is None:

                conn.execute(

                    "INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",

                    (username, hash_password(password), role),

                )

    refresh_inventory_list()

    refresh_restock_queue()

def refresh_inventory_list():

    """Refresh the Python List from the persistent SQLite inventory table."""

    global INVENTORY_LIST

    with db() as conn:

        rows = conn.execute("SELECT * FROM items ORDER BY name COLLATE NOCASE").fetchall()

    with DATA_LOCK:

        INVENTORY_LIST = [dict(row) for row in rows]

        return list(INVENTORY_LIST)

def refresh_restock_queue():

    """Load pending requests into a FIFO deque, oldest request first."""

    with db() as conn:

        rows = conn.execute(

            "SELECT id,item_id,item_name,requested_qty,requested_by,note,status,created_at "

            "FROM restock_requests WHERE status='Pending' ORDER BY id"

        ).fetchall()

    with DATA_LOCK:

        RESTOCK_QUEUE.clear()

        RESTOCK_QUEUE.extend(dict(row) for row in rows)

        return list(RESTOCK_QUEUE)

def clean_text(value, label, limit, required=False):

    value = str(value if value is not None else "").strip()

    if required and not value:

        raise ValueError(f"{label} is required.")

    if len(value) > limit:

        raise ValueError(f"{label} must be {limit} characters or fewer.")

    if any(ord(ch) < 32 for ch in value):

        raise ValueError(f"{label} contains invalid characters.")

    return value

def clean_integer(value, label, minimum=0, maximum=2_000_000_000):

    if isinstance(value, bool) or value is None or str(value).strip() == "":

        raise ValueError(f"{label} must be a whole number.")

    try:

        number = int(str(value).strip())

    except (ValueError, TypeError, OverflowError):

        raise ValueError(f"{label} must be a whole number.")

    if str(value).strip() not in (str(number), f"+{number}"):

        raise ValueError(f"{label} must be a whole number.")

    if number < minimum or number > maximum:

        raise ValueError(f"{label} must be between {minimum} and {maximum}.")

    return number

def clean_price(value):

    try:

        price = float(value)

    except (ValueError, TypeError, OverflowError):

        raise ValueError("Price must be a valid number.")

    if not math.isfinite(price) or price < 0 or price > 1_000_000_000:

        raise ValueError("Price must be a valid non-negative amount.")

    return round(price, 2)

def clean_item(data):

    if not isinstance(data, dict):

        raise ValueError("Invalid item data.")

    name = clean_text(data.get("name"), "Item name", 100, required=True)

    category = clean_text(data.get("category", "Other"), "Category", 50) or "Other"

    quantity = clean_integer(data.get("quantity", 0), "Quantity")

    min_stock = clean_integer(data.get("min_stock", 5), "Minimum stock")

    price = clean_price(data.get("price", 0))

    return name, category, quantity, min_stock, price

def clean_request(data):

    if not isinstance(data, dict):

        raise ValueError("Invalid restock request.")

    item_id = clean_integer(data.get("item_id"), "Item", 1)

    requested_qty = clean_integer(data.get("requested_qty"), "Requested quantity", 1, 1_000_000)

    note = clean_text(data.get("note", ""), "Note", 250)

    return item_id, requested_qty, note

class Handler(BaseHTTPRequestHandler):

    server_version = "SchoolSuppliesLocal/2.0"

    def log_message(self, *_args):

        # Avoid logging usernames, request bodies, or session details.

        pass

    def send_json(self, payload, status=200, extra_headers=None):

        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        self.send_response(status)

        self.send_header("Content-Type", "application/json; charset=utf-8")

        self.send_header("Content-Length", str(len(body)))

        self.send_header("Cache-Control", "no-store")

        self.send_header("X-Content-Type-Options", "nosniff")

        self.send_header("Referrer-Policy", "same-origin")

        if extra_headers:

            for key, value in extra_headers:

                self.send_header(key, value)

        self.end_headers()

        self.wfile.write(body)

    def send_page(self):

        body = PAGE.encode("utf-8")

        self.send_response(200)

        self.send_header("Content-Type", "text/html; charset=utf-8")

        self.send_header("Content-Length", str(len(body)))

        self.send_header("Cache-Control", "no-store")

        self.send_header("X-Content-Type-Options", "nosniff")

        self.send_header("Referrer-Policy", "same-origin")

        self.send_header(

            "Content-Security-Policy",

            "default-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:;",

        )

        self.end_headers()

        self.wfile.write(body)

    def read_json(self):

        try:

            length = int(self.headers.get("Content-Length", "0"))

            if length < 0 or length > MAX_REQUEST_BYTES:

                raise ValueError("Request is too large.")

            raw = self.rfile.read(length) if length else b"{}"

            data = json.loads(raw.decode("utf-8"))

            if not isinstance(data, dict):

                raise ValueError("Invalid request body.")

            return data

        except (json.JSONDecodeError, UnicodeDecodeError):

            raise ValueError("Invalid JSON request.")

        except (TypeError, OverflowError):

            raise ValueError("Invalid request length.")

    def get_path(self):

        return urlparse(self.path).path

    def path_id(self, prefix):

        path = self.get_path().rstrip("/")

        if not path.startswith(prefix):

            return None

        try:

            return int(path[len(prefix):])

        except (ValueError, TypeError):

            return None

    def session_user(self):

        cookie = SimpleCookie()

        try:

            cookie.load(self.headers.get("Cookie", ""))

            morsel = cookie.get("sid")

            token = morsel.value if morsel else ""

        except Exception:

            token = ""

        if not token:

            return None

        now = time.time()

        with SESSIONS_LOCK:

            session = SESSIONS.get(token)

            if not session:

                return None

            if session["expires"] < now:

                SESSIONS.pop(token, None)

                return None

            session["expires"] = now + SESSION_TTL_SECONDS

            return {"username": session["username"], "role": session["role"], "token": token}

    def require_user(self):

        user = self.session_user()

        if not user:

            self.send_json({"error": "Please log in first."}, 401)

        return user

    def require_role(self, *roles):

        user = self.require_user()

        if not user:

            return None

        if user["role"] not in roles:

            self.send_json({"error": "Permission denied."}, 403)

            return None

        return user

    def check_csrf(self, user):

        supplied = self.headers.get("X-CSRF-Token", "")

        if not hmac.compare_digest(supplied, user["token"]):

            self.send_json({"error": "Invalid session token. Refresh and try again."}, 403)

            return False

        return True

    def do_GET(self):

        path = self.get_path()

        if path in ("/", "/index.html"):

            self.send_page()

            return

        if path == "/api/session":

            user = self.session_user()

            if user:

                self.send_json({"logged_in": True, "username": user["username"],

                                "role": user["role"], "csrf": user["token"]})

            else:

                self.send_json({"logged_in": False})

            return

        if path == "/api/items":

            if not self.require_user():

                return

            self.send_json(refresh_inventory_list())

            return

        if path == "/api/restock-requests":

            if not self.require_user():

                return

            with db() as conn:

                rows = conn.execute(

                    "SELECT id,item_id,item_name,requested_qty,requested_by,note,status,created_at,"

                    "processed_by,processed_at FROM restock_requests ORDER BY id DESC LIMIT 300"

                ).fetchall()

            self.send_json([dict(row) for row in rows])

            return

        self.send_json({"error": "Not found."}, 404)

    def do_POST(self):

        path = self.get_path()

        try:

            if path == "/api/login":

                data = self.read_json()

                username = clean_text(data.get("username"), "Username", 80, required=True)

                password = str(data.get("password", ""))

                if len(password) > 200:

                    raise ValueError("Invalid username or password.")

                with db() as conn:

                    row = conn.execute(

                        "SELECT username,password_hash,role FROM users WHERE username=?", (username,)

                    ).fetchone()

                if not row or not verify_password(password, row["password_hash"]):

                    self.send_json({"error": "Incorrect username or password."}, 401)

                    return

                token = secrets.token_urlsafe(32)

                with SESSIONS_LOCK:

                    SESSIONS[token] = {"username": row["username"], "role": row["role"],

                                       "expires": time.time() + SESSION_TTL_SECONDS}

                self.send_json(

                    {"ok": True, "username": row["username"], "role": row["role"], "csrf": token},

                    extra_headers=[("Set-Cookie", f"sid={token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age={SESSION_TTL_SECONDS}")],

                )

                return

            if path == "/api/logout":

                user = self.require_user()

                if not user or not self.check_csrf(user):

                    return

                with SESSIONS_LOCK:

                    SESSIONS.pop(user["token"], None)

                self.send_json({"ok": True}, extra_headers=[

                    ("Set-Cookie", "sid=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0")

                ])

                return

            if path == "/api/exit":

                user = self.require_user()

                if not user or not self.check_csrf(user):

                    return

                with SESSIONS_LOCK:

                    SESSIONS.clear()

                self.send_json({"ok": True, "message": "Application is shutting down."})

                threading.Thread(target=self.server.shutdown, daemon=True).start()

                return

            if path == "/api/items":

                user = self.require_role("admin")

                if not user or not self.check_csrf(user):

                    return

                values = clean_item(self.read_json())

                with db() as conn:

                    cur = conn.execute(

                        "INSERT INTO items(name,category,quantity,min_stock,price) VALUES(?,?,?,?,?)", values

                    )

                    new_id = cur.lastrowid

                refresh_inventory_list()

                self.send_json({"id": new_id}, 201)

                return

            if path == "/api/restock-requests":

                user = self.require_role("staff", "admin")

                if not user or not self.check_csrf(user):

                    return

                item_id, qty, note = clean_request(self.read_json())

                with db() as conn:

                    item = conn.execute("SELECT id,name FROM items WHERE id=?", (item_id,)).fetchone()

                    if not item:

                        self.send_json({"error": "Selected item does not exist."}, 404)

                        return

                    cur = conn.execute(

                        "INSERT INTO restock_requests(item_id,item_name,requested_qty,requested_by,note) "

                        "VALUES(?,?,?,?,?)", (item_id, item["name"], qty, user["username"], note)

                    )

                    request_id = cur.lastrowid

                    request = conn.execute(

                        "SELECT id,item_id,item_name,requested_qty,requested_by,note,status,created_at "

                        "FROM restock_requests WHERE id=?", (request_id,)

                    ).fetchone()

                with DATA_LOCK:

                    RESTOCK_QUEUE.append(dict(request))

                self.send_json({"ok": True, "id": request_id}, 201)

                return

            request_id = None

            if path.startswith("/api/restock-requests/") and path.endswith("/process"):

                try:

                    request_id = int(path[len("/api/restock-requests/"):-len("/process")].strip("/"))

                except (ValueError, TypeError):

                    request_id = None

            if request_id is not None and request_id > 0:

                user = self.require_role("admin")

                if not user or not self.check_csrf(user):

                    return

                data = self.read_json()

                action = str(data.get("action", "")).lower().strip()

                if action not in ("approve", "reject"):

                    raise ValueError("Choose approve or reject.")

                with DATA_LOCK:

                    first = RESTOCK_QUEUE[0] if RESTOCK_QUEUE else None

                    if not first or int(first["id"]) != request_id:

                        self.send_json({"error": "Process pending requests in FIFO order. Refresh the queue."}, 409)

                        return

                    with db() as conn:

                        request = conn.execute(

                            "SELECT * FROM restock_requests WHERE id=? AND status='Pending'", (request_id,)

                        ).fetchone()

                        if not request:

                            self.send_json({"error": "This request is no longer pending."}, 409)

                            refresh_restock_queue()

                            return

                        if action == "approve":

                            conn.execute(

                                "UPDATE items SET quantity=quantity+? WHERE id=?",

                                (request["requested_qty"], request["item_id"]),

                            )

                            status = "Approved"

                        else:

                            status = "Rejected"

                        conn.execute(

                            "UPDATE restock_requests SET status=?,processed_by=?,processed_at=CURRENT_TIMESTAMP WHERE id=?",

                            (status, user["username"], request_id),

                        )

                    RESTOCK_QUEUE.popleft()

                refresh_inventory_list()

                self.send_json({"ok": True, "status": status})

                return

            self.send_json({"error": "Not found."}, 404)

        except (ValueError, TypeError, OverflowError) as exc:

            self.send_json({"error": str(exc) or "Invalid request data."}, 400)

        except sqlite3.IntegrityError:

            self.send_json({"error": "The request could not be saved because related data changed."}, 409)

        except sqlite3.Error:

            self.send_json({"error": "A database error occurred. Your existing data was not intentionally cleared."}, 500)

    def do_PUT(self):

        path = self.get_path()

        item_id = self.path_id("/api/items/")

        if item_id is None or path == "/api/items":

            self.send_json({"error": "Invalid item ID."}, 400)

            return

        user = self.require_user()

        if not user or not self.check_csrf(user):

            return

        try:

            data = self.read_json()

            with db() as conn:

                existing = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()

                if not existing:

                    self.send_json({"error": "Item not found."}, 404)

                    return

                if user["role"] == "admin":

                    values = clean_item(data)

                    conn.execute(

                        "UPDATE items SET name=?,category=?,quantity=?,min_stock=?,price=? WHERE id=?",

                        (*values, item_id),

                    )

                else:

                    quantity = clean_integer(data.get("quantity"), "Quantity")

                    conn.execute("UPDATE items SET quantity=? WHERE id=?", (quantity, item_id))

            refresh_inventory_list()

            self.send_json({"ok": True})

        except (ValueError, TypeError, OverflowError) as exc:

            self.send_json({"error": str(exc) or "Invalid item data."}, 400)

        except sqlite3.Error:

            self.send_json({"error": "A database error occurred."}, 500)

    def do_DELETE(self):

        user = self.require_role("admin")

        if not user or not self.check_csrf(user):

            return

        item_id = self.path_id("/api/items/")

        if item_id is None:

            self.send_json({"error": "Invalid item ID."}, 400)

            return

        try:

            with db() as conn:

                cur = conn.execute("DELETE FROM items WHERE id=?", (item_id,))

            if cur.rowcount == 0:

                self.send_json({"error": "Item not found."}, 404)

            else:

                refresh_inventory_list()

                refresh_restock_queue()

                self.send_json({"ok": True})

        except sqlite3.Error:

            self.send_json({"error": "Could not delete this item."}, 500)

PAGE = r'''<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">

<title>School Supplies Inventory</title>

<style>

:root{--bg:#f4f6fb;--card:#fff;--text:#1f2937;--muted:#6b7280;--line:#e5e7eb;--brand:#2563eb;--warn:#b45309;--warnbg:#fef3c7;--danger:#dc2626;--ok:#15803d}

@media(prefers-color-scheme:dark){:root{--bg:#0f172a;--card:#1e293b;--text:#e5e7eb;--muted:#94a3b8;--line:#334155;--brand:#60a5fa;--warn:#fcd34d;--warnbg:#451a03;--danger:#f87171;--ok:#4ade80}}

*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--text)}

header{background:var(--brand);color:#fff;padding:18px 28px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}header h1{margin:0;font-size:1.5rem}header p{margin:4px 0 0;opacity:.9}

main{max-width:1050px;margin:24px auto;padding:0 16px}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:20px}

.stat,.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px}.stat b{display:block;font-size:1.6rem}.stat span{color:var(--muted);font-size:.85rem}.card{margin-bottom:20px}.card h2{margin:0 0 12px;font-size:1.1rem}

form#itemForm{display:grid;grid-template-columns:2fr 1.3fr 1fr 1fr 1fr auto;gap:10px;align-items:end}label{font-size:.78rem;color:var(--muted);display:block;margin-bottom:3px}

input,select{width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--text);font-size:.95rem}

button{cursor:pointer;border:none;border-radius:8px;padding:9px 14px;font-size:.9rem;font-weight:600;background:var(--brand);color:#fff}button:disabled{opacity:.45;cursor:not-allowed}button.ghost{background:transparent;color:var(--text);border:1px solid var(--line)}button.danger{background:transparent;color:var(--danger);border:1px solid var(--line)}button.qty{padding:3px 10px;background:transparent;color:var(--text);border:1px solid var(--line)}

.toolbar{display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap}.toolbar input{flex:2;min-width:180px}.toolbar select{flex:1;min-width:140px}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}th,td{padding:10px 8px;text-align:left;border-bottom:1px solid var(--line);white-space:nowrap}th{font-size:.78rem;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}

.badge{padding:3px 9px;border-radius:99px;font-size:.75rem;font-weight:700}.badge.ok{background:rgba(21,128,61,.15);color:var(--ok)}.badge.low{background:var(--warnbg);color:var(--warn)}.badge.out{background:rgba(220,38,38,.15);color:var(--danger)}.qtycell{display:flex;align-items:center;gap:8px}.empty{text-align:center;color:var(--muted);padding:28px}

#loginPanel{max-width:420px;margin:70px auto;padding:24px;background:var(--card);border:1px solid var(--line);border-radius:14px}#loginPanel h2{margin-top:0}#loginForm{display:grid;gap:12px}#loginError{color:var(--danger);min-height:1.2em}.hidden{display:none!important}.userbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.rolepill{border:1px solid #ffffff80;border-radius:99px;padding:4px 9px;font-size:.8rem}

.nav{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.nav button.active{background:#1d4ed8}.small{font-size:.82rem;color:var(--muted)}.request-form{display:grid;grid-template-columns:2fr 1fr 2fr auto;gap:10px;align-items:end}.actions{display:flex;gap:6px;align-items:center}.notice{padding:10px 12px;border-radius:8px;background:var(--warnbg);color:var(--warn);margin-bottom:12px}

@media(max-width:800px){form#itemForm{grid-template-columns:1fr 1fr}.request-form{grid-template-columns:1fr 1fr}}

@media(max-width:480px){form#itemForm,.request-form{grid-template-columns:1fr}header{padding:16px}}

</style></head><body>

<header><div><h1>&#128218; School Supplies Inventory</h1><p>Track stock, low items, and inventory value.</p></div>

<div id="userbar" class="userbar hidden"><span id="whoami"></span><span id="role" class="rolepill"></span><button id="logoutBtn" class="ghost">Log out</button></div></header>

<section id="loginPanel"><h2>Sign in</h2><p>Log in using your assigned Admin or Staff account.</p>

<form id="loginForm"><div><label for="username">Username</label><input id="username" autocomplete="username" required maxlength="80"></div>

<div><label for="password">Password</label><input id="password" type="password" autocomplete="current-password" required maxlength="200"></div>

<button type="submit">Log in</button><div id="loginError" role="alert"></div></form></section>

<main id="app" class="hidden">

<nav class="nav" aria-label="Main menu"><button id="navDashboard" class="active" type="button">Dashboard</button><button id="navRequests" type="button">Restock Requests</button><button id="navReports" type="button">Reports</button><button id="navExit" class="danger" type="button">Exit</button></nav>

<section id="dashboardView">

<div class="stats"><div class="stat"><b id="sItems">0</b><span>Item types</span></div><div class="stat"><b id="sUnits">0</b><span>Total units</span></div><div class="stat"><b id="sLow">0</b><span>Low / out of stock</span></div><div class="stat"><b id="sValue">0</b><span>Total value (PHP)</span></div></div>

<div class="card" id="formCard"><h2 id="formTitle">Add item</h2><form id="itemForm">

<div><label for="name">Item name</label><input id="name" required maxlength="100" placeholder="e.g. Eraser"></div>

<div><label for="category">Category</label><select id="category"><option>Writing</option><option>Paper</option><option>Art</option><option>Tools</option><option>Bags &amp; Storage</option><option>Other</option></select></div>

<div><label for="quantity">Quantity</label><input id="quantity" type="number" min="0" max="2000000000" step="1" value="0" required></div>

<div><label for="min_stock">Min. stock</label><input id="min_stock" type="number" min="0" max="2000000000" step="1" value="5" required></div>

<div><label for="price">Price (PHP)</label><input id="price" type="number" min="0" max="1000000000" step="0.01" value="0" required></div>

<div style="display:flex;gap:6px"><button type="submit" id="saveBtn">Add</button><button type="button" class="ghost" id="cancelBtn" hidden>Cancel</button></div></form></div>

<div class="card"><div class="toolbar"><input id="search" placeholder="Search items..."><select id="filterCat"><option value="">All categories</option></select><select id="filterStock"><option value="">All stock levels</option><option value="low">Low stock only</option><option value="out">Out of stock only</option></select></div>

<div class="table-wrap"><table><thead><tr><th>Item</th><th>Category</th><th>Quantity</th><th>Status</th><th>Price</th><th>Value</th><th>Actions</th></tr></thead><tbody id="rows"></tbody></table><div class="empty" id="empty" hidden>No items found.</div></div></div>

</section>

<section id="requestsView" class="hidden">

<div class="card" id="requestFormCard"><h2>Submit a restock request</h2><p class="small">Requests are processed by the Admin in first-in, first-out (FIFO) order.</p>

<form id="requestForm" class="request-form"><div><label for="requestItem">Item</label><select id="requestItem" required></select></div><div><label for="requestQty">Requested quantity</label><input id="requestQty" type="number" min="1" max="1000000" step="1" value="10" required></div><div><label for="requestNote">Note (optional)</label><input id="requestNote" maxlength="250" placeholder="Reason or details"></div><button type="submit">Submit request</button></form></div>

<div class="card"><h2>Restock request queue</h2><div id="queueNotice" class="notice">Pending requests are displayed oldest first.</div><div class="table-wrap"><table><thead><tr><th>Request #</th><th>Item</th><th>Qty</th><th>Requested by</th><th>Note</th><th>Status</th><th>Action</th></tr></thead><tbody id="requestRows"></tbody></table><div id="requestEmpty" class="empty" hidden>No restock requests found.</div></div></div>

</section>

<section id="reportsView" class="hidden"><div class="card"><h2>Inventory report</h2><p id="reportSummary"></p><div class="table-wrap"><table><thead><tr><th>Category</th><th>Item types</th><th>Total units</th><th>Low / out</th><th>Inventory value</th></tr></thead><tbody id="reportRows"></tbody></table></div></div></section>

</main>

<script>

let items=[],requests=[],editingId=null,currentUser=null,csrfToken='';

const $=id=>document.getElementById(id);

const peso=n=>Number(n||0).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});

async function api(method,url,body){

 const headers={'Content-Type':'application/json'};if(csrfToken)headers['X-CSRF-Token']=csrfToken;

 const res=await fetch(url,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});

 let data={};try{data=await res.json()}catch{}

 if(!res.ok){if(res.status===401&&url!='/api/login')showLogin();throw new Error(data.error||'Request failed.')}return data;

}

function showLogin(){currentUser=null;csrfToken='';$('app').classList.add('hidden');$('userbar').classList.add('hidden');$('loginPanel').classList.remove('hidden');}

function showApp(user){currentUser=user;$('loginPanel').classList.add('hidden');$('app').classList.remove('hidden');$('userbar').classList.remove('hidden');$('whoami').textContent=user.username;$('role').textContent=user.role.toUpperCase();$('formCard').classList.toggle('hidden',user.role!=='admin');$('requestFormCard').classList.remove('hidden');loadAll().catch(e=>alert(e.message));}

async function checkSession(){try{const s=await api('GET','/api/session');if(s.logged_in){csrfToken=s.csrf;showApp({username:s.username,role:s.role});}else showLogin();}catch{showLogin();}}

async function loadAll(){items=await api('GET','/api/items');requests=await api('GET','/api/restock-requests');render();renderRequests();renderReport();}

function status(i){return i.quantity===0?'out':i.quantity<=i.min_stock?'low':'ok';}

function render(){

 const q=$('search').value.toLowerCase(),cat=$('filterCat').value,st=$('filterStock').value;

 const cats=[...new Set(items.map(i=>i.category))].sort((a,b)=>a.localeCompare(b));const old=$('filterCat').value;

 $('filterCat').innerHTML='<option value="">All categories</option>';cats.forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c;$('filterCat').append(o)});$('filterCat').value=cats.includes(old)?old:'';

 const shown=items.filter(i=>i.name.toLowerCase().includes(q)&&(!cat||i.category===cat)&&(!st||(st==='out'?status(i)==='out':status(i)!=='ok')));

 $('sItems').textContent=items.length;$('sUnits').textContent=items.reduce((s,i)=>s+i.quantity,0).toLocaleString();$('sLow').textContent=items.filter(i=>status(i)!=='ok').length;$('sValue').textContent=peso(items.reduce((s,i)=>s+i.quantity*i.price,0));

 const body=$('rows');body.innerHTML='';$('empty').hidden=shown.length>0;

 for(const i of shown){const s=status(i),label={ok:'In stock',low:'Low stock',out:'Out of stock'}[s],tr=document.createElement('tr');

  tr.innerHTML='<td></td><td></td><td><div class="qtycell"><button class="qty" data-act="dec" aria-label="Decrease quantity">&minus;</button><b>'+i.quantity+'</b><button class="qty" data-act="inc" aria-label="Increase quantity">+</button></div></td><td><span class="badge '+s+'">'+label+'</span></td><td>&#8369;'+peso(i.price)+'</td><td>&#8369;'+peso(i.price*i.quantity)+'</td><td class="actions"></td>';

  tr.children[0].textContent=i.name;tr.children[1].textContent=i.category;const actions=tr.querySelector('.actions');

  if(currentUser.role==='admin'){const edit=document.createElement('button');edit.className='ghost';edit.textContent='Edit';edit.dataset.act='edit';actions.append(edit);const del=document.createElement('button');del.className='danger';del.textContent='Delete';del.dataset.act='del';actions.append(del);}else actions.textContent='Quantity only';

  tr.addEventListener('click',e=>{const a=e.target.dataset.act;if(a)action(a,i)});body.append(tr);

 }

 renderRequestItemOptions();

}

function renderRequestItemOptions(){const select=$('requestItem'),old=select.value;select.innerHTML='';items.forEach(i=>{const o=document.createElement('option');o.value=i.id;o.textContent=i.name+' (current: '+i.quantity+')';select.append(o)});if(items.some(i=>String(i.id)===old))select.value=old;}

async function action(act,i){try{

 if(act==='inc'||act==='dec'){const qty=Math.max(0,i.quantity+(act==='inc'?1:-1));await api('PUT','/api/items/'+i.id,{quantity:qty,...(currentUser.role==='admin'?{name:i.name,category:i.category,min_stock:i.min_stock,price:i.price}:{})});await loadAll();}

 else if(act==='del'){if(confirm('Delete "'+i.name+'"?')){await api('DELETE','/api/items/'+i.id);await loadAll();}}

 else if(act==='edit'){editingId=i.id;for(const k of ['name','quantity','min_stock','price'])$(k).value=i[k];if(![...$('category').options].some(o=>o.value===i.category))$('category').add(new Option(i.category));$('category').value=i.category;$('formTitle').textContent='Edit item';$('saveBtn').textContent='Save';$('cancelBtn').hidden=false;window.scrollTo({top:0,behavior:'smooth'});}

 }catch(e){alert(e.message)}}

function resetForm(){editingId=null;$('itemForm').reset();$('formTitle').textContent='Add item';$('saveBtn').textContent='Add';$('cancelBtn').hidden=true;}

function renderRequests(){const body=$('requestRows');body.innerHTML='';$('requestEmpty').hidden=requests.length>0;const pending=requests.filter(r=>r.status==='Pending').sort((a,b)=>a.id-b.id);const nextId=pending.length?pending[0].id:null;

 for(const r of requests){const tr=document.createElement('tr');tr.innerHTML='<td>#'+r.id+'</td><td></td><td>'+r.requested_qty+'</td><td></td><td></td><td><span class="badge '+(r.status==='Approved'?'ok':r.status==='Rejected'?'out':'low')+'">'+r.status+'</span></td><td class="actions"></td>';tr.children[1].textContent=r.item_name;tr.children[3].textContent=r.requested_by;tr.children[4].textContent=r.note||'—';const actions=tr.querySelector('.actions');

  if(currentUser.role==='admin'&&r.status==='Pending'){const approve=document.createElement('button');approve.textContent='Approve';approve.disabled=r.id!==nextId;approve.addEventListener('click',()=>processRequest(r.id,'approve'));const reject=document.createElement('button');reject.className='danger';reject.textContent='Reject';reject.disabled=r.id!==nextId;reject.addEventListener('click',()=>processRequest(r.id,'reject'));actions.append(approve,reject);if(r.id!==nextId)actions.title='Process the oldest pending request first.';}else actions.textContent=r.status==='Pending'?'Waiting for Admin':(r.processed_by?'By '+r.processed_by:'—');body.append(tr);

 }

 $('queueNotice').textContent=pending.length?('Pending requests: '+pending.length+'. The oldest request (#'+pending[0].id+') must be processed first (FIFO).'):'There are no pending restock requests.';

}

async function processRequest(id,action){if(!confirm((action==='approve'?'Approve':'Reject')+' restock request #'+id+'?'))return;try{await api('POST','/api/restock-requests/'+id+'/process',{action});await loadAll();}catch(e){alert(e.message);}}

function renderReport(){const groups={};for(const i of items){if(!groups[i.category])groups[i.category]={count:0,units:0,low:0,value:0};const g=groups[i.category];g.count++;g.units+=i.quantity;if(status(i)!=='ok')g.low++;g.value+=i.quantity*i.price;}

 $('reportSummary').textContent='There are '+items.length+' item types and '+items.reduce((s,i)=>s+i.quantity,0)+' total units. Total inventory value: PHP '+peso(items.reduce((s,i)=>s+i.quantity*i.price,0))+'.';const body=$('reportRows');body.innerHTML='';Object.keys(groups).sort().forEach(cat=>{const g=groups[cat],tr=document.createElement('tr');tr.innerHTML='<td></td><td>'+g.count+'</td><td>'+g.units+'</td><td>'+g.low+'</td><td>&#8369;'+peso(g.value)+'</td>';tr.children[0].textContent=cat;body.append(tr);});}

function showView(name){for(const n of ['Dashboard','Requests','Reports']){$(n.toLowerCase()+'View').classList.toggle('hidden',n.toLowerCase()!==name);$('nav'+n).classList.toggle('active',n.toLowerCase()===name);}}

$('navDashboard').addEventListener('click',()=>showView('dashboard'));$('navRequests').addEventListener('click',()=>showView('requests'));$('navReports').addEventListener('click',()=>showView('reports'));

$('navExit').addEventListener('click',async()=>{

 if(!currentUser)return;

 if(!confirm('Are you sure you want to Exit and stop the School Supplies Inventory program?'))return;

 const exitButton=$('navExit');exitButton.disabled=true;exitButton.textContent='Exiting...';

 try{

  await api('POST','/api/exit',{});

  document.body.innerHTML='<main style="max-width:650px;margin:12vh auto;padding:24px;font-family:system-ui;text-align:center"><h1>School Supplies Inventory Closed</h1><p>The program has exited successfully. You may now close this browser tab.</p></main>';

 }catch(err){exitButton.disabled=false;exitButton.textContent='Exit';alert(err.message||'Could not exit the program.');}

});

$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginError').textContent='';try{const d=await api('POST','/api/login',{username:$('username').value.trim(),password:$('password').value});csrfToken=d.csrf;$('password').value='';showApp({username:d.username,role:d.role});}catch(err){$('loginError').textContent=err.message;}});

$('logoutBtn').addEventListener('click',async()=>{try{await api('POST','/api/logout',{});}catch(e){}showLogin();$('loginForm').reset();});

$('itemForm').addEventListener('submit',async e=>{e.preventDefault();if(!currentUser||currentUser.role!=='admin')return alert('Admin permission required.');const data={name:$('name').value,category:$('category').value,quantity:$('quantity').value,min_stock:$('min_stock').value,price:$('price').value};try{if(editingId)await api('PUT','/api/items/'+editingId,data);else await api('POST','/api/items',data);resetForm();await loadAll();}catch(err){alert(err.message);}});

$('cancelBtn').addEventListener('click',resetForm);

$('requestForm').addEventListener('submit',async e=>{e.preventDefault();if(!currentUser)return;try{await api('POST','/api/restock-requests',{item_id:$('requestItem').value,requested_qty:$('requestQty').value,note:$('requestNote').value});$('requestForm').reset();$('requestQty').value=10;await loadAll();alert('Restock request added to the queue.');}catch(err){alert(err.message);}});

['search','filterCat','filterStock'].forEach(id=>$(id).addEventListener('input',render));

checkSession();

</script></body></html>'''

def main():
    init_db()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.daemon_threads = True
    print(f"School Supplies Inventory running on port {PORT}")
    print("Admin demo login: admin / 123")
    print("Staff demo login: staff / 123")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\\nSchool Supplies Inventory stopped.")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
